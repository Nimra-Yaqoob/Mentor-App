// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:mentorapp/firebase_services/session_manager.dart';

// import 'menteehomepage.dart';

// class EnrollmentsPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     // Current user ka ID fetch karna
//     String currentUserId = SessionManager.getUserId();

//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Followings'),
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           onPressed: () => Navigator.of(context).pushReplacement(
//             MaterialPageRoute(
//               builder: (context) => const MenteeHome(),
//             ),
//           ),
//         ),
//       ),
//       body: SafeArea(
//         child: Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: StreamBuilder(
//             // Firestore query ko modify karna current user ke mentors ke details ko retrieve karne ke liye
//             stream: FirebaseFirestore.instance
//                 .collection('mentors')
//                 .where('enrollments', arrayContains: currentUserId)
//                 .snapshots(),
//             builder:
//                 (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
//               if (snapshot.hasError) {
//                 return Center(child: Text('Error: ${snapshot.error}'));
//               }

//               if (snapshot.connectionState == ConnectionState.waiting) {
//                 return Center(child: CircularProgressIndicator());
//               }

//               List<DocumentSnapshot> enrolledMentors = snapshot.data!.docs;

//               if (enrolledMentors.isEmpty) {
//                 // Agar koi mentors enrolled nahi hain, toh appropriate message display karein
//                 return Center(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Text(
//                         'You are not following any mentors.',
//                         style: TextStyle(fontSize: 16, color: Colors.grey),
//                       ),
//                     ],
//                   ),
//                 );
//               }

//               // Sabse pehle mentor ka document select karna
//               DocumentSnapshot mentorSnapshot = enrolledMentors.first;
//               var mentorData = mentorSnapshot.data() as Map<String, dynamic>;

//               // MentorTile widget se mentor ki information display karna
//               return MentorTile(
//                 name: mentorData['fullName'] ?? '',
//                 specialty:
//                     (mentorData['passions'] as List<dynamic>?)?.join(', ') ??
//                         '',
//                 image: mentorData['imageUrl'] ?? '',
//               );
//             },
//           ),
//         ),
//       ),
//     );
//   }
// }

// class MentorTile extends StatelessWidget {
//   final String name;
//   final String specialty;
//   final String? image;

//   const MentorTile({
//     Key? key,
//     required this.name,
//     required this.specialty,
//     this.image,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       margin: const EdgeInsets.symmetric(vertical: 4.0),
//       padding: const EdgeInsets.all(8.0),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         border: Border(
//           bottom: BorderSide(
//             color: Colors.grey[300]!,
//             width: 1.0,
//           ),
//         ),
//       ),
//       child: Row(
//         children: [
//           CircleAvatar(
//             radius: 25.0,
//             backgroundImage: image != null ? NetworkImage(image!) : null,
//             backgroundColor: Colors.grey[200],
//           ),
//           const SizedBox(width: 12.0),
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   name,
//                   style: const TextStyle(
//                     fontSize: 16.0,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//                 SizedBox(height: 4.0),
//                 Text(
//                   specialty,
//                   style: const TextStyle(
//                     fontSize: 14.0,
//                     fontWeight: FontWeight.w400,
//                     color: Colors.grey,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           GestureDetector(
//             onTap: () {
//               // Handle tap on MentorTile if needed
//             },
//             child: const Icon(Icons.more_vert),
//           ),
//         ],
//       ),
//     );
//   }
// }
