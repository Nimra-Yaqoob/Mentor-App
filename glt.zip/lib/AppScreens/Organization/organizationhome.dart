import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mentorapp/firebase_services/session_manager.dart'; // Session manager ko yahan import karen

class OrganizationHome extends StatefulWidget {
  const OrganizationHome({Key? key}) : super(key: key);

  @override
  State<OrganizationHome> createState() => _OrganizationHomeState();
}

class _OrganizationHomeState extends State<OrganizationHome> {
  late Future<List<Map<String, dynamic>>> mentorsData;

  @override
  void initState() {
    super.initState();
    mentorsData = fetchMentorsData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mentors Data'),
      ),
      body: Center(
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: mentorsData,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            } else if (snapshot.hasData) {
              return ListView.builder(
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  final mentorData = snapshot.data![index];
                  return MentorCard(
                    fullName: mentorData['fullName'],
                    organization: mentorData['organization'],
                  );
                },
              );
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            } else {
              return Text('No data found.');
            }
          },
        ),
      ),
    );
  }

  Future<List<Map<String, dynamic>>> fetchMentorsData() async {
    try {
      String organizationName = await getOrganizationName();

      // Mentors collection se mentors ke details ko retrieve karte hain
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
          .collection('mentors')
          .where('organization', isEqualTo: organizationName)
          .get();

      List<Map<String, dynamic>> mentorsData = [];
      for (QueryDocumentSnapshot doc in querySnapshot.docs) {
        if (doc.exists) {
          Map<String, dynamic> mentorData = {
            'fullName': doc['fullName'],
            'organization': doc['organization'],
          };
          mentorsData.add(mentorData);
        }
      }
      return mentorsData;
    } catch (e) {
      print('Error fetching mentor data: $e');
      return [];
    }
  }

  Future<String> getOrganizationName() async {
    try {
      String currentUserId = SessionManager
          .getUserId(); // SessionManager se current user ID fetch karte hain

      // Firestore se current user ka organization name fetch karte hain
      DocumentSnapshot snapshot = await FirebaseFirestore.instance
          .collection('organizations')
          .doc(currentUserId)
          .get();

      if (snapshot.exists) {
        return snapshot['organizationName'];
      } else {
        return 'Organization not found';
      }
    } catch (e) {
      print('Error fetching organization name: $e');
      return 'Error';
    }
  }
}

class MentorCard extends StatelessWidget {
  final String fullName;
  final String organization;

  const MentorCard({
    required this.fullName,
    required this.organization,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: ListTile(
        leading: CircleAvatar(
          child: Icon(Icons.person),
        ),
        title: Text(fullName),
        subtitle: Text(organization),
      ),
    );
  }
}
