import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mentorapp/AppScreens/constant.dart';

class MentorsList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 300,
      child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('mentors').snapshots(),
        builder: (BuildContext context,
            AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>> snapshot) {
          if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          }

          final mentors = snapshot.data?.docs ?? [];

          return ListView.builder(
            itemCount: mentors.length,
            itemBuilder: (context, index) {
              final mentor = mentors[index].data();
              return MentorCard(
                name: mentor['fullName'] ?? '',
                category: mentor['experience']?['category'] ?? '',
                rating: mentor['rating'] ?? 0.0,
                mentorId: mentors[index].id,
              );
            },
          );
        },
      ),
    );
  }
}

class MentorCard extends StatefulWidget {
  final String name;
  final String category;
  final double rating;
  final String mentorId;

  const MentorCard({
    Key? key,
    required this.name,
    required this.category,
    required this.rating,
    required this.mentorId,
  }) : super(key: key);

  @override
  _MentorCardState createState() => _MentorCardState();
}

class _MentorCardState extends State<MentorCard> {
  bool isFavorite = false;
  String? imageUrl;

  @override
  void initState() {
    super.initState();
    // Fetch image URL from Firestore using mentorId
    fetchImageUrl();
  }

  void fetchImageUrl() async {
    try {
      var document = await FirebaseFirestore.instance
          .collection('mentors')
          .doc(widget.mentorId)
          .get();

      setState(() {
        imageUrl = document['imageUrl'];
      });
    } catch (e) {
      print('Error fetching image URL: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 20.0,
              backgroundImage: imageUrl != null
                  ? NetworkImage(imageUrl!)
                  : null, // Null-aware operator
            ),
            SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.name,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    widget.category,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(
                        Icons.star,
                        color: Colors.yellow[700],
                        size: 16,
                      ),
                      SizedBox(width: 4),
                      Text(
                        widget.rating.toString(),
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(width: 10),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                primary: secondaryColor,
                onPrimary: Colors.white,
              ),
              child: Text(
                'Track',
                style: TextStyle(fontSize: 14),
              ),
            ),
            SizedBox(width: 10),
            Icon(
              Icons.message_rounded,
              color: Colors.black45,
              size: 24,
            ),
            SizedBox(width: 5),
            IconButton(
              icon: Icon(
                isFavorite ? Icons.favorite : Icons.favorite_border,
                color: isFavorite ? Colors.red : Colors.black45,
                size: 24,
              ),
              onPressed: () {
                setState(() {
                  isFavorite = !isFavorite;
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}
