class SessionController {
  static final SessionController _session = SessionController._internal();
  String? userId;
  factory SessionController() {
    return _session;
  }

  SessionController._internal() {}
}

class SessionManager {
  static String _userId = '';
  static String _userImageUrl = '';

  static void setUserId(String userId) {
    _userId = userId;
  }

  static String getUserId() {
    return _userId;
  }

  static void setUserImageUrl(String userImageUrl) {
    _userImageUrl = userImageUrl;
  }

  static String getUserImageUrl() {
    return _userImageUrl;
  }
}


// class SessionManager {
//   static String _userId = '';

//   static void setUserId(String userId) {
//     _userId = userId;
//   }

//   static String getUserId() {
//     return _userId;
//   }
// }




