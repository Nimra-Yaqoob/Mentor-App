import 'package:flutter/material.dart';

class panel extends StatelessWidget {
  const panel({super.key});
  static const String id = "webmain";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(children: [
        Expanded(
            child: Container(
          color: Colors.amber,
        )),
      ]),
    );
  }
}
