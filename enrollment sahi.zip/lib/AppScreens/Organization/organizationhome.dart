import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:mentorapp/AppScreens/Organization/mentorcard.dart';
import 'package:mentorapp/AppScreens/Organization/organizationprofile.dart';
import 'package:mentorapp/AppScreens/constant.dart';
import 'package:mentorapp/firebase_services/session_manager.dart';

import 'organizationavdrawer.dart';

class OrgnaizationHome extends StatefulWidget {
  const OrgnaizationHome({Key? key}) : super(key: key);

  @override
  State<OrgnaizationHome> createState() => _OrgnaizationHomeState();
}

class _OrgnaizationHomeState extends State<OrgnaizationHome> {
  String searchQuery = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: NavDrawer(),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: Builder(
          builder: (context) {
            return IconButton(
              onPressed: () => Scaffold.of(context).openDrawer(),
              icon: Icon(Icons.menu, color: Colors.black),
            );
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications_rounded),
            color: Colors.black,
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 50,
                margin: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        onChanged: (value) {
                          setState(() {
                            searchQuery = value;
                          });
                        },
                        decoration: InputDecoration(
                          hintText: 'Search, e.g., Umair',
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.only(left: 20),
                        ),
                      ),
                    ),
                    Container(
                      width: 70,
                      height: 60,
                      decoration: BoxDecoration(
                        color: primaryColor,
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                        ),
                      ),
                      child: IconButton(
                        onPressed: () {
                          // Clear the search query
                          setState(() {
                            searchQuery = '';
                          });
                        },
                        icon: Icon(
                          Icons.search,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Display search results
              searchQuery.isEmpty
                  ? Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Mentors',
                                style: TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w500)),
                            Icon(
                              Icons.arrow_forward,
                              color: secondaryColor,
                            ),
                          ],
                        ),
                        SizedBox(height: 6),
                        // Display all mentors when no search query
                        MentorsList(),
                      ],
                    )
                  : SearchResult(searchQuery: searchQuery),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        margin: EdgeInsets.symmetric(vertical: 7, horizontal: 5),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(50),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.1),
                blurRadius: 30,
                offset: Offset(0, 10),
              ),
            ]),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 7),
          child: GNav(
            padding: EdgeInsets.all(9),
            backgroundColor: Colors.white,
            color: Colors.black54,
            activeColor: Colors.white,
            tabBackgroundColor: primaryColor,
            gap: 8,
            tabs: [
              GButton(
                icon: Icons.home,
                text: 'Home',
                onPressed: () =>
                    Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (context) => const OrgnaizationHome(),
                )),
              ),
              GButton(icon: Icons.event_available, text: 'Sessions'),
              GButton(
                icon: Icons.message_rounded,
                text: 'Inbox',
                onPressed: () {},
              ),
              GButton(
                icon: Icons.person,
                text: 'Profile',
                onPressed: () {
                  // Get the user ID from SessionManager
                  String userId = SessionManager.getUserId();

                  // Navigate to OrganizationProfile with userId
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(
                      builder: (context) => OrganizationProfile(userId: userId),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SearchResult extends StatelessWidget {
  final String searchQuery;

  const SearchResult({Key? key, required this.searchQuery}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('mentors')
          .where('fullName', isGreaterThanOrEqualTo: searchQuery)
          .where('fullName', isLessThan: searchQuery + 'z')
          .snapshots(),
      builder: (BuildContext context,
          AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>> snapshot) {
        if (snapshot.hasError) {
          return Text('Error: ${snapshot.error}');
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return CircularProgressIndicator();
        }

        final mentors = snapshot.data?.docs ?? [];

        if (mentors.isEmpty) {
          return Text('No results found for "$searchQuery"');
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Search Results',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
                // You can add more widgets or customize the UI as needed
              ],
            ),
            SizedBox(height: 6),
            // Display search results
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: mentors.length,
              itemBuilder: (context, index) {
                final mentor = mentors[index].data();
                return MentorCard(
                  name: mentor['fullName'] ?? '',
                  category: mentor['experience']?['category'] ?? '',
                  rating: mentor['rating'] ?? 0.0,
                  mentorId: mentors[index].id,
                );
              },
            ),
          ],
        );
      },
    );
  }
}
