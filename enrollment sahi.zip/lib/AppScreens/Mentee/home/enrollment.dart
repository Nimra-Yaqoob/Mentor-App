import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:mentorapp/AppScreens/Mentee/home/menteehomepage.dart';

class EnrollmentProfile extends StatefulWidget {
  final String mentorId;

  const EnrollmentProfile({super.key, required this.mentorId});

  @override
  State<EnrollmentProfile> createState() => _EnrollmentProfileState();
}

class _EnrollmentProfileState extends State<EnrollmentProfile> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MenteeHome(),
                ),
              );
            },
            icon: Icon(Icons.arrow_back_ios),
          ),
          title: Text("Profile"),
          actions: [
            IconButton(
              onPressed: () {},
              icon: Icon(Icons.more_vert),
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            future: FirebaseFirestore.instance
                .collection('mentors')
                .doc(widget.mentorId)
                .get(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
              if (snapshot.hasError) {
                return Center(
                  child: Text('Error fetching data'),
                );
              }
              if (!snapshot.hasData || !snapshot.data!.exists) {
                return Center(
                  child: Text('No Data'),
                );
              }

              var doc = snapshot.data!.data()!;
              String name = doc['fullName'];
              String email = doc['email'];
              String imageUrl =
                  doc['imageUrl']; // assuming you have an image URL field

              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        CircleAvatar(
                          radius: 50,
                          backgroundImage: NetworkImage(imageUrl),
                        ),
                        SizedBox(
                          height: 16,
                        ),
                        Text(
                          name,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        Text(
                          "Fashion",
                          style: TextStyle(
                            fontSize: 16,
                          ),
                        ),
                        SizedBox(
                          height: 4,
                        ),
                        Text(
                          "Models",
                          style: TextStyle(
                            fontSize: 16,
                          ),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        TextButton(
                          onPressed: () {},
                          child: Text(
                            email,
                            style: TextStyle(
                              color: Colors.blue,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            Text(
                              "0",
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(
                              height: 4,
                            ),
                            Text(
                              "Posts",
                              style: TextStyle(
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            Text(
                              "0",
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(
                              height: 4,
                            ),
                            Text(
                              "Followers",
                              style: TextStyle(
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            Text(
                              "0",
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(
                              height: 4,
                            ),
                            Text(
                              "Following",
                              style: TextStyle(
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    //                   child: Row(
                    // children: [
                    //   Expanded(
                    //     child: FutureBuilder<DocumentSnapshot>(
                    //       future: doc.reference
                    //           .collection('followers')
                    //           .doc(FirebaseAuth.instance.currentUser!.uid)
                    //           .get(),
                    //       builder: (context, snapshot) {
                    //         if (snapshot.hasData) {
                    //           if (snapshot.data?.exists ?? false) {
                    //             return ElevatedButton(
                    //               onPressed: () async {
                    //                 await doc.reference
                    //                     .collection("followers")
                    //                     .doc(FirebaseAuth.instance.currentUser!.uid)
                    //                     .delete();
                    //                 setState(() {});
                    //               },
                    //               style: ElevatedButton.styleFrom(
                    //                 backgroundColor: Color(0xff673AB7),
                    //                 padding: EdgeInsets.symmetric(
                    //                   vertical: 16,
                    //                 ),
                    //                 textStyle: TextStyle(
                    //                   fontSize: 18,
                    //                   fontWeight: FontWeight.bold,
                    //                 ),
                    //               ),
                    //               child: Text(
                    //                 "Un Follow",
                    //                 style: TextStyle(
                    //                   color: Colors.white,
                    //                 ),
                    //               ),
                    //             );
                    //           } else {
                    //             return ElevatedButton(
                    //               onPressed: () async {
                    //                 await doc.reference
                    //                     .collection("followers")
                    //                     .doc(FirebaseAuth.instance.currentUser!.uid)
                    //                     .set({
                    //                   'time': DateTime.now(),
                    //                 });
                    //                 setState(() {});
                    //               },
                    //               style: ElevatedButton.styleFrom(
                    //                 backgroundColor: Color(0xff673AB7),
                    //                 padding: EdgeInsets.symmetric(
                    //                   vertical: 16,
                    //                 ),
                    //                 textStyle: TextStyle(
                    //                   fontSize: 18,
                    //                   fontWeight: FontWeight.bold,
                    //                 ),
                    //               ),
                    //               child: Text(
                    //                 "Follow",
                    //                 style: TextStyle(
                    //                   color: Colors.white,
                    //                 ),
                    //               ),
                    //             );
                    //           }
                    //         } else {
                    //           return const Center(child: CircularProgressIndicator());
                    //         }
                    //       },
                    //     ),
                    //   ),
                    //                       SizedBox(
                    //                         width: 16,
                    //                       ),
                    //                       IconButton(
                    //                         onPressed: () {},
                    //                         icon: Icon(Icons.send),
                    //                         iconSize: 32,
                    //                       ),
                    //                     ],
                    //                   ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _buildImageItem(
                          imageUrl: 'assets/image1.jpg',
                          icon: Icons.add,
                        ),
                        _buildImageItem(
                          imageUrl: 'assets/image2.jpg',
                        ),
                        _buildImageItem(
                          imageUrl: 'assets/image3.jpg',
                        ),
                        _buildImageItem(
                          imageUrl: 'assets/image4.jpg',
                        ),
                        _buildImageItem(
                          imageUrl: 'assets/image5.jpg',
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildImageItem({
    required String imageUrl,
    IconData? icon,
  }) {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        image: DecorationImage(
          image: AssetImage(imageUrl),
          fit: BoxFit.cover,
        ),
      ),
      child: icon != null
          ? Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Icon(
                  icon,
                  color: Colors.white,
                ),
              ),
            )
          : null,
    );
  }
}

    



// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart'; // Import Firestore
// import 'package:mentorapp/AppScreens/Mentee/home/menteehomepage.dart';
// import 'package:mentorapp/AppScreens/constant.dart';

// class EnrollmentProfile extends StatefulWidget {
//   final String mentorId; // Pass mentor ID to fetch specific mentor profile
//   const EnrollmentProfile({Key? key, required this.mentorId}) : super(key: key);

//   @override
//   _EnrollmentProfileState createState() => _EnrollmentProfileState();
// }

// class _EnrollmentProfileState extends State<EnrollmentProfile> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           onPressed: () {
//             Navigator.of(context).pushReplacement(
//                 MaterialPageRoute(builder: (context) => const MenteeHome()));
//           },
//         ),
//         actions: [
//           IconButton(
//             icon: Icon(Icons.menu),
//             onPressed: () {
//               // Add menu button functionality here
//             },
//           ),
//         ],
//       ),
//       backgroundColor: primaryColor,
//       body: FutureBuilder<DocumentSnapshot>(
//         future: FirebaseFirestore.instance
//             .collection('mentors')
//             .doc(widget.mentorId)
//             .get(),
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return Center(child: CircularProgressIndicator());
//           }
//           if (snapshot.hasError) {
//             return Center(child: Text('Error: ${snapshot.error}'));
//           }
//           if (!snapshot.hasData || snapshot.data == null) {
//             return Center(child: Text('No data found'));
//           }
//           var mentorData = snapshot.data!.data() as Map<String, dynamic>;

//           return Center(
//             child: Padding(
//               padding: const EdgeInsets.all(16.0),
//               child: Card(
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(20.0),
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.all(16.0),
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     children: <Widget>[
//                       CircleAvatar(
//                         radius: 50.0,
//                         backgroundImage:
//                             NetworkImage(mentorData['imageUrl'] ?? ''),
//                       ),
//                       SizedBox(height: 10),
//                       Text(
//                         mentorData['fullName'] ?? 'No Name',
//                         style: TextStyle(
//                           fontSize: 24,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                       SizedBox(height: 10),
//                       Text(
//                         mentorData['experience']?['description'] ??
//                             'No Description',
//                         textAlign: TextAlign.center,
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                       ),
//                       SizedBox(height: 20),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: [
//                           FutureBuilder<DocumentSnapshot>(
//                             future: FirebaseFirestore.instance
//                                 .collection('mentors')
//                                 .doc(widget.mentorId)
//                                 .collection('followers')
//                                 .doc(FirebaseAuth.instance.currentUser!.uid)
//                                 .get(),
//                             builder: (context, snapshot) {
//                               if (snapshot.connectionState ==
//                                   ConnectionState.waiting) {
//                                 return CircularProgressIndicator();
//                               }
//                               if (snapshot.hasError) {
//                                 return Text('Error: ${snapshot.error}');
//                               }
//                               if (snapshot.hasData &&
//                                   snapshot.data != null &&
//                                   snapshot.data!.exists) {
//                                 return ElevatedButton.icon(
//                                   onPressed: () async {
//                                     await FirebaseFirestore.instance
//                                         .collection('mentors')
//                                         .doc(widget.mentorId)
//                                         .collection('followers')
//                                         .doc(FirebaseAuth
//                                             .instance.currentUser!.uid)
//                                         .delete();
//                                     setState(() {});
//                                   },
//                                   icon: Icon(Icons.remove, color: Colors.white),
//                                   label: Text(
//                                     "Unfollow",
//                                     style: TextStyle(
//                                       color: Colors.white,
//                                     ),
//                                   ),
//                                 );
//                               }
//                               return ElevatedButton.icon(
//                                 onPressed: () async {
//                                   await FirebaseFirestore.instance
//                                       .collection('mentors')
//                                       .doc(widget.mentorId)
//                                       .collection('followers')
//                                       .doc(FirebaseAuth
//                                           .instance.currentUser!.uid)
//                                       .set({
//                                     'time': DateTime.now(),
//                                   });
//                                   setState(() {});
//                                 },
//                                 icon: Icon(Icons.add, color: Colors.white),
//                                 label: Text(
//                                   "Follow",
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                   ),
//                                 ),
//                               );
//                             },
//                           ),
//                           SizedBox(width: 10),
//                           ElevatedButton.icon(
//                             onPressed: () {
//                               // Message button action
//                             },
//                             icon: Icon(
//                               Icons.message,
//                               color: Colors.white,
//                             ),
//                             label: Text(
//                               'Message',
//                               style: TextStyle(
//                                 color: Colors.white,
//                               ),
//                             ),
//                             style: ElevatedButton.styleFrom(
//                               primary: secondaryColor,
//                               shape: RoundedRectangleBorder(
//                                 borderRadius: BorderRadius.circular(30.0),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }




// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:mentorapp/AppScreens/Mentee/home/menteehomepage.dart';
// import 'package:mentorapp/AppScreens/constant.dart';

// class EnrollmentProfile extends StatefulWidget {
//   final String mentorId;
//   const EnrollmentProfile({Key? key, required this.mentorId}) : super(key: key);

//   @override
//   _EnrollmentProfileState createState() => _EnrollmentProfileState();
// }

// class _EnrollmentProfileState extends State<EnrollmentProfile> {
//   @override
//   Widget build(BuildContext context) {
//     // Static data to mimic the fetched data
//     final Map<String, dynamic> mentorData = {
//       'imageUrl': 'https://via.placeholder.com/150',
//       'fullName': 'John Doe',
//       'experience': {'description': 'Experienced Mentor in Flutter Development'}
//     };

//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           onPressed: () {
//             Navigator.of(context).pushReplacement(
//                 MaterialPageRoute(builder: (context) => const MenteeHome()));
//           },
//         ),
//         actions: [
//           IconButton(
//             icon: Icon(Icons.menu),
//             onPressed: () {
//               // Add menu button functionality here
//             },
//           ),
//         ],
//       ),
//       backgroundColor: primaryColor,
//       body: Center(
//         child: Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: Card(
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(20.0),
//             ),
//             child: Padding(
//               padding: const EdgeInsets.all(16.0),
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: <Widget>[
//                   CircleAvatar(
//                     radius: 50.0,
//                     backgroundImage: NetworkImage(mentorData['imageUrl'] ?? ''),
//                   ),
//                   SizedBox(height: 10),
//                   Text(
//                     mentorData['fullName'] ?? 'No Name',
//                     style: TextStyle(
//                       fontSize: 24,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   SizedBox(height: 10),
//                   Text(
//                     mentorData['experience']?['description'] ??
//                         'No Description',
//                     textAlign: TextAlign.center,
//                     style: TextStyle(
//                       fontSize: 16,
//                     ),
//                   ),
//                   SizedBox(height: 20),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       ElevatedButton.icon(
//                         onPressed: () {
//                           // Follow button action
//                         },
//                         icon: Icon(Icons.add, color: Colors.white),
//                         label: Text(
//                           "Follow",
//                           style: TextStyle(
//                             color: Colors.white,
//                           ),
//                         ),
//                       ),
//                       SizedBox(width: 10),
//                       ElevatedButton.icon(
//                         onPressed: () {
//                           // Message button action
//                         },
//                         icon: Icon(
//                           Icons.message,
//                           color: Colors.white,
//                         ),
//                         label: Text(
//                           'Message',
//                           style: TextStyle(
//                             color: Colors.white,
//                           ),
//                         ),
//                         style: ElevatedButton.styleFrom(
//                           primary: secondaryColor,
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(30.0),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }



// Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: [
//                           FutureBuilder<DocumentSnapshot>(
//                             future: doc.reference
//                                 .collection('followers')
//                                 .doc(FirebaseAuth.instance.currentUser!.uid)
//                                 .get(),
//                             builder: (context, snapshot) {
//                               if (snapshot.hasData) {
//                                 if (snapshot.data?.exists ?? false) {
//                                   return ElevatedButton.icon(
//                                     onPressed: () async {
//                                       await doc.reference
//                                           .collection("followers")
//                                           .doc(FirebaseAuth
//                                               .instance.currentUser!.uid)
//                                           .delete();
//                                       setState(() {});
//                                     },
//                                     icon: Icon(Icons.add, color: Colors.white),
//                                     label: Text(
//                                       "Un Follow",
//                                       style: TextStyle(
//                                         color: Colors.white,
//                                       ),
//                                     ),
//                                   );
//                                 }
//                                 return ElevatedButton.icon(
//                                   onPressed: () async {
//                                     await doc.reference
//                                         .collection("followers")
//                                         .doc(FirebaseAuth
//                                             .instance.currentUser!.uid)
//                                         .set({
//                                       'time': DateTime.now(),
//                                     });
//                                     setState(() {});
//                                   },
//                                   icon: Icon(Icons.add, color: Colors.white),
//                                   label: Text(
//                                     "Follow",
//                                     style: TextStyle(
//                                       color: Colors.white,
//                                     ),
//                                   ),
//                                 );
//                               } else {
//                                 return const CircularProgressIndicator();
//                               }
//                             },
//                           ),
//                           SizedBox(width: 10),
//                           ElevatedButton.icon(
//                             onPressed: () {
//                               // Message button action
//                             },
//                             icon: Icon(
//                               Icons.message,
//                               color: Colors.white,
//                             ),
//                             label: Text(
//                               'Message',
//                               style: TextStyle(
//                                 color: Colors.white,
//                               ),
//                             ),
//                             style: ElevatedButton.styleFrom(
//                               primary: secondaryColor,
//                               shape: RoundedRectangleBorder(
//                                 borderRadius: BorderRadius.circular(30.0),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),