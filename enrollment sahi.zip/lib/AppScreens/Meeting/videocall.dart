import 'dart:convert';
import 'package:agora_uikit/agora_uikit.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:zego_uikit_prebuilt_video_conference/zego_uikit_prebuilt_video_conference.dart';
import 'package:mentorapp/AppScreens/Meeting/newmeeting.dart';

// class VideoCall extends StatefulWidget {
//   final String channelName;

//   VideoCall({required this.channelName});

//   @override
//   _VideoCallState createState() => _VideoCallState();
// }

// class _VideoCallState extends State<VideoCall> {
//   late final AgoraClient _client;
//   bool _loading = true;
//   String tempToken = "";

//   @override
//   void initState() {
//     super.initState();
//     getToken(widget.channelName);
//   }

//   Future<void> getToken(String channelName) async {
//     String link =
//         "https://8a8b7caa-2849-4d12-8dff-28ff4472e8ff-00-3tq13vnyqtgfw.sisko.replit.dev/rtc/$channelName/publisher/uid/1";
//     Response _response = await get(Uri.parse(link));
//     if (_response.statusCode == 200) {
//       Map data = jsonDecode(_response.body);
//       setState(() {
//         tempToken = data["token"];
//       });
//       initializeAgoraClient(tempToken, channelName);
//     } else {
//       print("Failed to fetch token");
//       setState(() {
//         _loading = false;
//       });
//     }
//   }

//   void initializeAgoraClient(String token, String channelName) {
//     _client = AgoraClient(
//       agoraConnectionData: AgoraConnectionData(
//         appId: "4c46dbbfd65c4e37ac1261a8847366ff",
//         tempToken: token,
//         channelName: channelName,
//       ),
//       enabledPermission: [Permission.camera, Permission.microphone],
//     );

//     Future.delayed(Duration(seconds: 1)).then(
//       (value) => setState(() {
//         _loading = false;
//       }),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         child: _loading
//             ? Center(
//                 child: CircularProgressIndicator(),
//               )
//             : Stack(
//                 children: [
//                   AgoraVideoViewer(
//                     client: _client,
//                   ),
//                   AgoraVideoButtons(client: _client)
//                 ],
//               ),
//       ),
//     );
//   }
// }

// token url
//
// // "https://8a8b7caa-2849-4d12-8dff-28ff4472e8ff-00-3tq13vnyqtgfw.sisko.replit.dev/rtc/test/publisher/uid/1";
// // "https://agora-node-tokenserver-1.davidcaleb.repl.co/access_token?channelName=${widget.channelName}";
//

// channelName: widget.channelName,

// String channelName = "FYP Project";

// VideoCall({required this.channelName});

class VideoCall extends StatefulWidget {
  const VideoCall({super.key});

  @override
  State<VideoCall> createState() => _VideoCallState();
}

class _VideoCallState extends State<VideoCall> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: ZegoUIKitPrebuiltVideoConference(
      userName: "Nimra",
      userID: "Nimra11",
      conferenceID: conferenceID,
      appID: 1460821462,
      appSign:
          "f481adafcaa7919b2487b36a21f9a85ff93dc38f8ce45dc8b91da56c9a07c655",
      config: ZegoUIKitPrebuiltVideoConferenceConfig(),
    ));
  }
}
