import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mentorapp/AppScreens/constant.dart';
import 'package:mentorapp/firebase_services/session_manager.dart';
import 'package:zego_zimkit/zego_zimkit.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // Firestore ko import kiya gaya hai

class ChatHome extends StatefulWidget {
  const ChatHome({Key? key})
      : super(key: key); // Make sure the key parameter is properly defined

  @override
  State<ChatHome> createState() => _ChatHomeState();
}

class _ChatHomeState extends State<ChatHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Messages"),
        centerTitle: true,
        backgroundColor: secondaryColor,
        actions: [
          PopupMenuButton(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(15)),
            ),
            position: PopupMenuPosition.under,
            icon: Icon(CupertinoIcons.add_circled),
            itemBuilder: (context) {
              return [
                PopupMenuItem(
                  value: "New Chat",
                  child: ListTile(
                    leading: Icon(CupertinoIcons.person_2_fill),
                    title: Text("New Chat", maxLines: 1),
                    onTap: () => ZIMKit().showDefaultNewPeerChatDialog(context),
                  ),
                ),
              ];
            },
          ),
        ],
      ),
      body: ZIMKitConversationListView(
        onPressed: (context, conversation, defaultAction) async {
          try {
            // Firestore se username retrieve kiya gaya hai
            final DocumentSnapshot<
                Map<String,
                    dynamic>> snapshot = await FirebaseFirestore.instance
                .collection('mentees')
                .doc(conversation
                    .id) // Assuming conversation.id represents the document ID where username is stored
                .get();

            if (snapshot.exists) {
              // Check if document exists
              String username = snapshot
                  .data()?['username']; // Access data directly using .data()
              // Username ko SessionManager mein store kiya gaya hai
              SessionManager.setUserName(username ?? ''); // Check for null

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return ZIMKitMessageListPage(
                      conversationID: username ??
                          '', // SessionManager se username pass kiya gaya hai
                      conversationType: conversation.type,
                    );
                  },
                ),
              );
            } else {
              // Handle if no documents found
              print('No document found for ID: ${conversation.id}');
              // Show some error message or handle it as per your requirement
            }
          } catch (error) {
            print('Error retrieving username: $error');
            // Handle the error
            // Show some error message or handle it as per your requirement
          }
        },
      ),
    );
  }
}
