import 'dart:math';
import 'package:flutter/material.dart';
import 'package:mentorapp/AppScreens/Meeting/videocall.dart';

class ConferenceCall extends StatefulWidget {
  const ConferenceCall({Key? key});

  @override
  State<ConferenceCall> createState() => _ConferenceCallState();
}

class _ConferenceCallState extends State<ConferenceCall> {
  final Random random = Random();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Conference Call'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context); // Navigate back to the previous screen
          },
        ),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Generate a random 8-digit conference ID
            int conferenceID = random.nextInt(99999999);
            print(
                "Generated Conference ID: $conferenceID"); // Print the generated ID
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => VideoCall(
                  conferenceID: conferenceID.toString(),
                ), // Pass the generated ID
              ),
            );
          },
          child: Text("Join Conference"),
        ),
      ),
    );
  }
}
