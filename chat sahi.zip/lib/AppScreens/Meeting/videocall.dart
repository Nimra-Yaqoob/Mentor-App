import 'package:flutter/material.dart';
import 'package:zego_uikit_prebuilt_video_conference/zego_uikit_prebuilt_video_conference.dart';
import 'package:mentorapp/firebase_services/session_manager.dart'; // Ensure correct import path
import 'package:cloud_firestore/cloud_firestore.dart'; // Import Firestore package

class VideoCall extends StatefulWidget {
  final String conferenceID;

  const VideoCall({Key? key, required this.conferenceID}) : super(key: key);

  @override
  _VideoCallState createState() => _VideoCallState();
}

class _VideoCallState extends State<VideoCall> {
  String userName = '';
  String userId = '';
  bool isEnrolled = false;
  bool isMentor = false;

  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }

  void _fetchUserData() async {
    userName = SessionManager.getUserName();
    userId = SessionManager.getUserId();
    if (userId.isNotEmpty) {
      bool isMentor = await _checkIfMentor(userId);
      setState(() {
        this.isMentor = isMentor;
      });

      if (!isMentor) {
        await _checkEnrollmentStatus(userId);
        bool conferenceExists =
            await _checkConferenceExists(widget.conferenceID);
        if (isEnrolled || conferenceExists) {
          _saveMeetingDetailsToFirestore(userName, userId, widget.conferenceID);
        } else {
          // Show an error message if the user is not enrolled and the conference ID does not exist
          _showNotEnrolledDialog();
        }
      } else {
        _saveMeetingDetailsToFirestore(userName, userId, widget.conferenceID);
      }
    }
    setState(() {}); // Refresh the UI after fetching user data
  }

  Future<bool> _checkIfMentor(String userId) async {
    DocumentSnapshot mentorSnapshot = await FirebaseFirestore.instance
        .collection('mentors')
        .doc(userId)
        .get();
    return mentorSnapshot.exists;
  }

  Future<void> _checkEnrollmentStatus(String userId) async {
    QuerySnapshot mentorSnapshot =
        await FirebaseFirestore.instance.collection('mentors').get();

    for (var mentorDoc in mentorSnapshot.docs) {
      DocumentSnapshot enrollmentSnapshot = await FirebaseFirestore.instance
          .collection('mentors')
          .doc(mentorDoc.id)
          .collection('enrollments')
          .doc(userId)
          .get();

      if (enrollmentSnapshot.exists) {
        isEnrolled = true;
        return;
      }
    }

    isEnrolled = false;
  }

  Future<bool> _checkConferenceExists(String conferenceID) async {
    QuerySnapshot meetingSnapshot = await FirebaseFirestore.instance
        .collection('meetings')
        .where('conferenceID', isEqualTo: conferenceID)
        .get();

    return meetingSnapshot.docs.isNotEmpty;
  }

  void _saveMeetingDetailsToFirestore(
      String userName, String userId, String conferenceID) async {
    CollectionReference meetings =
        FirebaseFirestore.instance.collection('meetings');
    await meetings.add({
      'userName': userName,
      'userId': userId,
      'conferenceID': conferenceID,
      'joinedAt': FieldValue.serverTimestamp(),
    });
  }

  void _showNotEnrolledDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Access Denied'),
        content: Text(
            'You are not enrolled with this mentor or the conference ID is invalid.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).pop(); // Go back to the previous screen
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: isMentor || isEnrolled
          ? ZegoUIKitPrebuiltVideoConference(
              userName: userName.isNotEmpty ? userName : 'Guest',
              userID: userId,
              conferenceID: widget.conferenceID,
              appID: 1460821462,
              appSign:
                  "f481adafcaa7919b2487b36a21f9a85ff93dc38f8ce45dc8b91da56c9a07c655",
              config: ZegoUIKitPrebuiltVideoConferenceConfig(),
            )
          : Center(
              child: Text('Checking enrollment status...'),
            ),
    );
  }
}
