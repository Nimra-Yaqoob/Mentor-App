import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mentorapp/AppScreens/Meeting/meetinghome.dart';
import 'package:mentorapp/AppScreens/Mentor/home%20page/mentorprofile.dart';
import 'package:mentorapp/AppScreens/Mentor/home%20page/navdrawer.dart';
import 'package:mentorapp/AppScreens/chat%20home/chathome.dart';
import 'package:mentorapp/AppScreens/constant.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:mentorapp/firebase_services/session_manager.dart';

class MentorHomePage extends StatefulWidget {
  const MentorHomePage({Key? key}) : super(key: key);

  @override
  State<MentorHomePage> createState() => _MentorHomePageState();
}

class _MentorHomePageState extends State<MentorHomePage> {
  late String _profilePictureUrl = '';
  late String _userId = '';
  late String _userName = ''; // Add a variable to store the user's name
  List<String> enrolledMenteesImages = []; // List to store mentees' images

  @override
  void initState() {
    super.initState();
    _fetchUserId();
  }

  void _fetchUserId() async {
    _userId = await SessionManager.getUserId();
    _fetchProfilePictureAndName();
    _fetchEnrolledMenteesImages();
  }

  void _fetchProfilePictureAndName() async {
    DocumentSnapshot? userDoc = await _fetchUserDetailsFromFirestore(_userId);
    if (userDoc != null && userDoc.exists) {
      setState(() {
        _profilePictureUrl = userDoc['imageUrl'] ?? '';
        _userName = userDoc['fullName'] ?? 'User'; // Fetch the user's name
      });
    }
  }

  Future<DocumentSnapshot?> _fetchUserDetailsFromFirestore(
      String userId) async {
    try {
      DocumentSnapshot documentSnapshot = await FirebaseFirestore.instance
          .collection('mentors')
          .doc(userId)
          .get();
      return documentSnapshot;
    } catch (e) {
      print("Error fetching user details: $e");
      return null;
    }
  }

  Future<void> _fetchEnrolledMenteesImages() async {
    QuerySnapshot enrollmentsSnapshot = await FirebaseFirestore.instance
        .collection('mentors')
        .doc(_userId) // Assuming mentor ID is the same as user ID
        .collection('enrollments')
        .get();

    setState(() {
      enrolledMenteesImages = enrollmentsSnapshot.docs
          .map((doc) => doc['imageUrl'] as String)
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: NavBar(), // Assuming you have a NavDrawer widget
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: Builder(
          builder: (context) {
            return IconButton(
              onPressed: () => Scaffold.of(context).openDrawer(),
              icon: Icon(Icons.menu, color: Colors.black),
            );
          },
        ),
        actions: [
          InkWell(
            onTap: () {
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (context) => MentorProfile(userId: _userId),
                ),
              );
            },
            child: CircleAvatar(
              radius: 25, // Adjust the radius as needed
              backgroundImage: _profilePictureUrl.isNotEmpty
                  ? NetworkImage(_profilePictureUrl)
                  : null,
              child: _profilePictureUrl.isEmpty
                  ? Icon(Icons.person, color: Colors.white)
                  : null,
            ),
          ),
          SizedBox(width: 20),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Hello $_userName !', // Display the user's name
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                ),
                Text(
                  'Furnish your skills with MentorSpark',
                  style: TextStyle(fontSize: 14, color: Colors.grey),
                ),
                SizedBox(height: 16),
                Center(
                  child: Container(
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: primaryColor,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            children: [
                              Text('Jun 29',
                                  style: TextStyle(color: Colors.white)),
                              Text('Wed',
                                  style: TextStyle(color: Colors.white)),
                            ],
                          ),
                        ),
                        SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Business',
                                  style: TextStyle(color: Colors.white)),
                              Text('Mr. Wade Smith',
                                  style: TextStyle(color: Colors.white)),
                              Text('10.00 AM',
                                  style: TextStyle(color: Colors.white)),
                            ],
                          ),
                        ),
                        Icon(Icons.arrow_forward_ios, color: Colors.white),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Mentees Profiles',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w500)),
                    Icon(Icons.arrow_forward, color: secondaryColor),
                  ],
                ),
                SizedBox(height: 12),
                Container(
                  height: 60,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: enrolledMenteesImages.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: CircleAvatar(
                          radius: 30,
                          backgroundImage:
                              NetworkImage(enrolledMenteesImages[index]),
                          backgroundColor: Colors.grey,
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Ongoing Tasks',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w500)),
                    Text('See All',
                        style: TextStyle(
                            fontSize: 13.sp,
                            fontWeight: FontWeight.w500,
                            color: secondaryColor)),
                  ],
                ),
                SizedBox(height: 12),
                Container(
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            '03 days | Dec 18, 2019',
                            style: TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Create additional pages',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Team members',
                            style: TextStyle(fontSize: 14, color: Colors.grey),
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: <Widget>[
                              CircleAvatar(
                                backgroundImage: NetworkImage(
                                    'https://via.placeholder.com/150'),
                              ),
                              SizedBox(width: 10),
                              CircleAvatar(
                                backgroundImage: NetworkImage(
                                    'https://via.placeholder.com/150'),
                              ),
                              SizedBox(width: 10),
                              CircleAvatar(
                                backgroundImage: NetworkImage(
                                    'https://via.placeholder.com/150'),
                              ),
                              SizedBox(width: 70),
                              CircularPercentIndicator(
                                radius: 30.0,
                                lineWidth: 8.0,
                                percent: 0.85,
                                center: Text(
                                  "85%",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12.0,
                                  ),
                                ),
                                progressColor: RedColor,
                                backgroundColor: Colors.grey,
                              ),
                            ],
                          ),
                          SizedBox(height: 14),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('More detailed',
                                  style: TextStyle(fontSize: 16)),
                              SizedBox(width: 100), // Adjust spacing as needed
                              Text('2d 8h',
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.grey)),
                              Icon(Icons.keyboard_arrow_down,
                                  color: Colors.grey),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        margin: EdgeInsets.symmetric(vertical: 7, horizontal: 5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(50),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.1),
              blurRadius: 30,
              offset: Offset(0, 10),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 7),
          child: GNav(
            padding: EdgeInsets.all(9),
            backgroundColor: Colors.white,
            color: Colors.black54,
            activeColor: Colors.white,
            tabBackgroundColor: primaryColor,
            gap: 8,
            tabs: [
              GButton(
                icon: Icons.home,
                text: 'Home',
                onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (context) => const MentorHomePage(),
                  ),
                ),
              ),
              GButton(
                icon: Icons.event_available,
                text: 'Sessions',
                onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (context) => HomePage(),
                  ),
                ),
              ),
              GButton(
                icon: Icons.message_rounded,
                text: 'Inbox',
                onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (context) => ChatHome(),
                  ),
                ),
              ),
              GButton(
                icon: Icons.person,
                text: 'Profile',
                onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (context) => MentorProfile(userId: _userId),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
