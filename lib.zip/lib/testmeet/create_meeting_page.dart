import 'package:flutter/material.dart';
import 'package:mentorapp/testmeet/meeting_list.dart';
import 'package:mentorapp/testmeet/meeting_service.dart';
import 'package:mentorapp/testmeet/zego_service.dart';
import 'package:uuid/uuid.dart'; // For generating unique meeting IDs

class CreateMeetingPage extends StatefulWidget {
  @override
  _CreateMeetingPageState createState() => _CreateMeetingPageState();
}

class _CreateMeetingPageState extends State<CreateMeetingPage> {
  final _titleController = TextEditingController();
  late String _meetingID;

  @override
  void initState() {
    super.initState();
    _meetingID = Uuid()
        .v4(); // Generate unique meeting ID when the widget is initialized
  }

  void _createMeeting() async {
    final title = _titleController.text;

    if (title.isNotEmpty) {
      try {
        // Create the meeting in Firestore
        await MeetingService().createMeeting(title, _meetingID);

        // Navigate to the meeting page
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => FutureBuilder<Widget>(
              future: ZegoService().joinMeeting(_meetingID),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Scaffold(
                    appBar: AppBar(title: Text('Joining Meeting')),
                    body: Center(child: CircularProgressIndicator()),
                  );
                } else if (snapshot.hasError) {
                  return Scaffold(
                    appBar: AppBar(title: Text('Error')),
                    body: Center(
                        child:
                            Text('Error joining meeting: ${snapshot.error}')),
                  );
                } else if (snapshot.hasData) {
                  return snapshot.data!;
                } else {
                  return Scaffold(
                    appBar: AppBar(title: Text('Error')),
                    body: Center(child: Text('No data available')),
                  );
                }
              },
            ),
          ),
        );
      } catch (e) {
        print(
            "Error creating meeting: $e"); // Print error message for debugging
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Create Meeting')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Meeting Title'),
            ),
            SizedBox(height: 20),
            Text('Meeting ID: $_meetingID'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _createMeeting,
              child: Text('Create Meeting'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        MeetingList(), // Navigate to MeetingList
                  ),
                );
              },
              child: Text('View Meeting List'),
            ),
          ],
        ),
      ),
    );
  }
}
