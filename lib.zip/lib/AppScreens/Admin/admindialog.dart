import 'package:flutter/material.dart';
import 'package:mentorapp/AppScreens/Admin/eco_button.dart';

class adminDialogue extends StatelessWidget {
  final String? title;

  const adminDialogue({Key? key, this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title!),
      actions: [
        EcoButton(
          title: 'CLOSE',
          onPress: () {
            Navigator.pop(context);
          },
        ),
      ],
    );
  }
}
