import 'package:flutter/material.dart';
import 'package:mentorapp/AppScreens/constant.dart';

class StorageInfo {
  final String? svgSrc, title;
  final int? numOfUsers;
  final Color? color;

  StorageInfo({
    this.svgSrc,
    this.title,
    this.numOfUsers,
    this.color,
  });
}

List demoMyFiles = [
  StorageInfo(
    title: "Visitors",
    numOfUsers: 1328,
    svgSrc: "building.svg", // Update the SVG file names
    color: primaryColor,
  ),
  StorageInfo(
    title: "Organizations",
    numOfUsers: 132,
    svgSrc: "building.svg", // Update the SVG file names
    color: Color(0xFFFFA113),
  ),
  StorageInfo(
    title: "Mentors",
    numOfUsers: 1328,
    svgSrc: "one_drive.svg", // Update the SVG file names
    color: Color(0xFFA4CDFF),
  ),
  StorageInfo(
    title: "Mentees",
    numOfUsers: 5328,
    svgSrc: "drop_box.svg", // Update the SVG file names
    color: Color(0xFF007EE5),
  ),
];
