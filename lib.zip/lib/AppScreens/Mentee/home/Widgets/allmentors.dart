import 'package:flutter/material.dart';
import 'package:mentorapp/AppScreens/Mentee/home/mentorcard.dart';

class AllMentors extends StatefulWidget {
  const AllMentors({Key? key}) : super(key: key);

  @override
  State<AllMentors> createState() => _AllMentorsState();
}

class _AllMentorsState extends State<AllMentors> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mentors'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: MentorsList(searchQuery: _searchQuery),
      ), // Displaying MentorsList widget here
    );
  }
}
