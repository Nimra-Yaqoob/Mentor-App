import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AcademiaMentorPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Academia Mentors'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: StreamBuilder(
            stream:
                FirebaseFirestore.instance.collection('mentors').snapshots(),
            builder:
                (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.hasError) {
                return Text('Error: ${snapshot.error}');
              }

              if (snapshot.connectionState == ConnectionState.waiting) {
                return CircularProgressIndicator();
              }

              // Filter mentors with category "Academia" correctly
              List<DocumentSnapshot> academiaMentors =
                  snapshot.data!.docs.where((doc) {
                var experience =
                    doc['experience'] as Map<String, dynamic>? ?? {};
                return experience['category'] == 'Academia';
              }).toList();

              if (academiaMentors.isEmpty) {
                return Center(
                  child: Text('No Academia Mentors found.'),
                );
              }

              return ListView(
                children: academiaMentors.map((DocumentSnapshot document) {
                  var data = document.data() as Map<String, dynamic>?;

                  if (data == null) {
                    return SizedBox(); // Return empty widget if data is null
                  }

                  return Mentors(
                    name: data['fullName'] ?? '',
                    specialty: data['experience']?['category'] ?? '',
                    image: data['imageUrl'] ?? '',
                  );
                }).toList(),
              );
            },
          ),
        ),
      ),
    );
  }
}

class Mentors extends StatelessWidget {
  final String name;
  final String specialty;
  final String? image;

  const Mentors({
    Key? key,
    required this.name,
    required this.specialty,
    this.image,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16.0),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () {
              // Handle list item tap
            },
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 20.0,
                    backgroundImage:
                        image != null ? NetworkImage(image!) : null,
                  ),
                  const SizedBox(width: 16.0),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          specialty,
                          style: const TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          name,
                          style: const TextStyle(
                            fontSize: 15.0,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 3), // Adjust spacing as needed
                  ElevatedButton(
                    onPressed: () {
                      // Add enrollment logic here
                    },
                    child: Text('Enroll'),
                  ),
                  GestureDetector(
                    onTap: () {
                      // Get the position of the icon
                      final RenderBox iconBox =
                          context.findRenderObject() as RenderBox;
                      final Offset iconPosition =
                          iconBox.localToGlobal(Offset.zero);

                      // Show the popup menu to the right of the icon
                      showMenu(
                        context: context,
                        position: RelativeRect.fromLTRB(
                          iconPosition.dx + iconBox.size.width,
                          iconPosition.dy, // Align vertically with the icon
                          iconPosition.dx +
                              iconBox.size.width +
                              10, // Adjust horizontal position as needed
                          iconPosition.dy +
                              iconBox.size
                                  .height, // Align vertically with the icon
                        ),
                        items: <PopupMenuEntry>[
                          PopupMenuItem(
                            child: Text('Point 1'),
                            value: 'point1',
                          ),
                          PopupMenuItem(
                            child: Text('Point 2'),
                            value: 'point2',
                          ),
                          PopupMenuItem(
                            child: Text('Point 3'),
                            value: 'point3',
                          ),
                        ],
                      ).then((value) {
                        // Handle menu item selection if needed
                      });
                    },
                    child: const Icon(Icons.more_vert),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
